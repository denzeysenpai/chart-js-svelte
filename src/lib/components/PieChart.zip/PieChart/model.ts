
export type ChartData = {
    label : string,
    value : any
}

export type PieData = {
    title : string,
    data: ChartData[]
}